export const ScheduleEvents = {
    "SERIE A":
        "https://www.livesoccertv.com/it/competitions/italy/serie-a/",

    "SERIE B":
        "https://www.livesoccertv.com/it/competitions/italy/serie-b/",

    "SERIE C":
        " https://www.livesoccertv.com/it/competitions/italy/lega-pro-1/",

    "SERIE A FEMMINILE - TIM VISION":
        " https://www.livesoccertv.com/it/competitions/italy/serie-a-women/",

    "HELBIZ":
        "https://www.livesoccertv.com/it/channels/helbiz/",

    "DAZN IT":
        "https://www.livesoccertv.com/it/channels/dazn-italy/",

    "CHAMPIONS LEAGUE - MEDIASET INFINITY+ (1)":
        "https://www.livesoccertv.com/it/channels/mediaset-italia-live/",

    "CHAMPIONS LEAGUE - MEDIASET INFINITY+ (2) ":

        " https://mediasetinfinity.mediaset.it/infinity-plus/champions-league",

    "CHAMPIONS LEAGUE - AMAZON PRIME VIDEO":
        " https://www.livesoccertv.com/it/channels/amazon-prime-video-italy/",

    "FORMULA 1":
        "https://sport.sky.it/formula-1/calendario",

    "MOTOGP":
        "https://sport.sky.it/motogp/calendario",

    "ELEVEN SPORT - SERIE C":
        " https://elevensports.com/it/league/serie-c-italia-kduign/schedule",

    " ELEVEN SPORT - TUTTI I LIVE":
        "https://elevensports.com/it/events?st=live,scheduled&cid=ck1dlr84u06xc0gv3f9lq2ct3,ckpwq21me01c416702096falk,ckpwpzfp401h4176he9va11jb,cjp46yr0g00di0guc5bzlshz8,ckpxsuoc4003p1670d81zgoxy,ckpxsxtd3003u1670egfp52cm,ckwc12wlq00vu17263g273ucw,ckyvp4x5n004y165e7uuqhqvc,ckzzedami01aj175n23jn62hg,ckpxtcbnq00431670dpk5flbu,ckpxtz9nt004p1670ci5gd74z,ckpxu12vf01ib162jhsdg5zph,ckvkv9r1b0108173h0oakfb3f,ckvghtz2500dz161ybq7tcjt3,cjp46yspn00f40hv3i71y4wix,ckwffw860007e16256kwnanuf,ckwffigrr009y170i3uws1ei6,ckwffmqr400791625cyzvcavp,ckz408azb01ev174ohbo36pnj,cktspnitg0000172ieasye2gn,ckpxtq76u004k1670ggs3fym7,ckpxw7bf201ig162jgihybt9u,ckya05ji502hn173kg5h2f8bi,ckwezebpu000w170raqe84j9z,ckz5k18830007163g6bkw7wdq,ckpxtfapc0040165a4wrualv8,cktwoopxz00gx161fdlvyhg5h,cktworb1x00ie170k18xzeosu,cktwz366u00ip161famu4f3p3,cktwzlt6000l3170k12g0dywz,cktx09avt000v173uhzp58fbm,cktwy1ext00ig161f3pyz0go2,ckretstcm001q165h8snfa5jp,ckreqwe7j001f165h8wf388rr,ckt91glkc001u1726b4i08tv5,ckz6y2982009o163ghwneb6r7",

    " FIFA+":
        "https://www.fifa.com/fifaplus/en/live",

    "BLUESPORT":
        "https://tv.blue.ch/tv-guide",

    " EUROSPORT PLAYER LIVE":
        "https://www.eurosportplayer.com/schedule",

    "TENNIS TV":
        "https://www.tennistv.com/live-schedule",

    "SKY IT":
        "https://guidatv.sky.it/?vista=griglia"
}