import React, { Component } from 'react'
import SidebarTemplate from '../common/SidebarTemplate/SidebarTemplate';
import Spinner from '../common/Spinner';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getStudents, setMessage, deleteStudent } from '../../actions/studentActions';
import { fetchHilightData, getElevenSportDta } from '../../api/api';
import { copy } from '../../utils/copy';
import axios from 'axios';

class Highlight extends Component {

    state = {
        feedback_msg: null,
        events: [],
        loading: true,
        tabId: "EVENT_STATUS_STARTED"
    }

    static getDerivedStateFromProps(props, state) {
        if (props.message.msg) {
            return {
                feedback_msg: props.message.msg
            }
        }
        return null;
    }

    async componentDidMount() {
        var config = {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',


             

            }
        }
        this.setState({ loading: true })
        let res = await fetchHilightData()
        // console.log(res.data)
        let data = res.data.entries
       await Promise.all( data.map(async (el, i) => {
           try {
            let url = el.media[0].publicUrl
            let re = await axios.get(url, config)
            if (re.status != 403)
            console.log(re.request.responseURL)
                el.media[0].publicUrl = re.request.responseURL
                console.log('edited', el.media[0].publicUrl)
           } catch (error) {
               console.log(error)
           }
           
        })).then(r=>{
            this.setState({ loading: false })
            this.setState({ events: data })
        })
        

    }

    componentWillUnmount() {
        this.props.setMessage(null);
    }

    searchStudent = (stage) => {
        const searchData = {
            stage: stage
        }
        this.props.getStudents(searchData);
    }

    addStudent = () => {
        this.props.history.push('/add-student');
    }

    onUpdateStudent = (student_id) => {
        this.props.history.push(`update-student/${student_id}`);
    }

    onDeleteStudent = (student_id, student_stage) => {
        if (window.confirm('Are You Sure ?')) {
            this.props.deleteStudent(student_id, student_stage);
            // this.props.getStudents({stage: student_stage});
        }
    }
    onFilter=(e)=>{
    
        let key=e.target.value
        if(key==""){
          
          this.componentDidMount()
      }
    
      
     else {
       
      let data =this.state.events
      console.log("ddddddd",data)
      console.log(key)
      var filteredArray =data.filter(function(el){
          return el.title.toUpperCase().indexOf(key.toUpperCase()) > -1;
        });
        this.setState({events:filteredArray})}
      }
    render() {

        const { loading } = this.state;
        let students = ['', '', '']
        let tableContent;
        if (loading) {
            tableContent = <div className='text-center'><Spinner /></div>;
        }
        else if (loading === false && students === null) {
            tableContent = <h1 className="display-4 text-danger">No data Found :(</h1>
        }
        else {
            let studentsTable = this.state.events.map(el => {
                let d = new Date(el.media[0].availableDate)
                let start = [d.getMonth() + 1,
                d.getDate(),
                d.getFullYear()].join('/') + ' ' +
                    [d.getHours(),
                    d.getMinutes(),
                    d.getSeconds()].join(':');

                let d2 = new Date(el.media[0].expirationDate)
                let end = [d2.getMonth() + 1,
                d2.getDate(),
                d2.getFullYear()].join('/') + ' ' +
                    [d2.getHours(),
                    d2.getMinutes(),
                    d2.getSeconds()].join(':');
let url =el.media[0].publicUrl.toString()
                return (
                    <tr key={el.id}>

                        <td >{el.title} </td>
                        <td >{el.description}</td>
                        <td >{start}</td>
                        <td >{end}</td>





                        <td >
                            <button className={`btn btn-${url.indexOf(".m3u8")>-1?"success":url.indexOf(".mpd")>-1?"warning":"danger"} btn-sm mr-1`} onClick={() => copy(url)}><i class="fa fa-copy"></i></button>

                        </td>
                    </tr>
                );
            });

            tableContent = (
                <table className="table table-striped table-sm">
                    <thead >
                        <tr>

                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Start time</th>
                            <th scope="col">End time</th>


                            <th scope="col">value</th>

                        </tr>
                    </thead>
                    <tbody>
                        {studentsTable}
                    </tbody>
                </table>
            );
        }

        return (
            <SidebarTemplate>

                {/* Start Success Message */}
                {(this.state.feedback_msg) ?
                    <div className={`alert alert-${this.state.feedback_msg.type} alert-dismissible fade show mt-3`} role="alert">
                        <strong>{this.state.feedback_msg.content}</strong>
                        <button type="button" className="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    : null}
                {/* End Success Message */}

                {/*    <button className='btn btn-primary float-right mt-2' onClick={this.addStudent}><i className='fas fa-plus'></i> Add New Channel</button> <br/> <br/> */}
              
                <div style={{
                        margin:10
                    }} >


                    <h4>Color Indicator</h4>
                    <a href="#" class="badge badge-success" style={{
                        marginRight:10
                    }}>m3u8</a>
                    <a href="#" class="badge badge-warning" style={{
                         marginRight:10
                    }}>mpd</a>
                    <a href="#" class="badge badge-danger" style={{
                      marginRight:10
                    }}>error</a>


                </div>
                <div class="input-group container" style={{
                    marginTop:20
                }} >
            <input class="form-control border-end-0 border rounded-pill" type="text"  id="example-search-input" placeholder="Search"  onChange={this.onFilter}/>
           
     </div>
                <div className='mt-5'>
                    {tableContent}
                </div>
            </SidebarTemplate>
        );
    }
}

Highlight.propTypes = {
    student: PropTypes.object.isRequired,
    message: PropTypes.object.isRequired,
    getStudents: PropTypes.func.isRequired,
    setMessage: PropTypes.func.isRequired,
    deleteStudent: PropTypes.func.isRequired,
}

const mapStateToProps = (state) => ({
    student: state.student,
    message: state.message
})

export default connect(mapStateToProps, { getStudents, setMessage, deleteStudent })(Highlight);
