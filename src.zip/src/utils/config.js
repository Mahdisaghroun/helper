//export const baseurl = 'http://185.221.173.62:4122'
//export const baseurl = 'http://localhost:4000'
let c = localStorage.getItem("config")?localStorage.getItem("config"): "http://185.221.173.62:4122"
export const baseurl =c;
