export const GET_ERRORS = 'GET_ERRORS';
export const SET_LOADING = 'SET_LOADING';
export const GET_ADMIN = 'GET_ADMIN';
export const GET_STUDENT = 'GET_STUDENT';
export const GET_STUDENTS = 'GET_STUDENTS';
export const SET_MESSAGE = 'SET_MESSAGE';
export const LOGOUT="LOGOUT"